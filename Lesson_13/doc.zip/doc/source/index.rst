.. Another one messenger documentation master file, created by
   sphinx-quickstart on Fri Jul  5 08:40:44 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Another one messenger's documentation!
=================================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   
   launcher
   common
   logs
   client
   server



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
